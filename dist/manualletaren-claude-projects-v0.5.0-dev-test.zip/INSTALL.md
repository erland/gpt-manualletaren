Lägg instruktionerna i Claude Projects och referenser som projektmaterial. Verifiera webbsökning och PDF-läsning.
