Aktivera kompatibla webbsök-/fetchverktyg i OpenCode. PDF-innehåll måste kunna läsas för verifieringsstatus.
